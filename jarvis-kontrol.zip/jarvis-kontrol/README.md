# JARVIS Kontrol

Aplikasi Android pendamping untuk kacamata pintar Q11-106C (SKMEI).

- Menampilkan **baterai kacamata** (laporan Bluetooth HP, broadcast sistem, atau BLE Battery Service).
- Menampilkan status koneksi dan peringatan saat baterai ≤ 20%.
- Tombol **Buka JARVIS**: membuka asisten JARVIS (ditenagai Claude) di Chrome.

## Membangun APK
Setiap push ke `main` menjalankan GitHub Actions (`.github/workflows/build-apk.yml`).
APK siap unduh muncul di tab **Releases** sebagai `JARVIS-Kontrol.apk`.

Lokal: buka folder ini di Android Studio, lalu Build → Build APK.
